<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'readme' => 'FEM - File Elements Mirroring plugin for MODx
==============================================

Introduction
-------------

If you create your templates and chunks in files and use include snippets to link them in the MODx manager, this plugin will save you the trouble of having to create the elements entirely.

Based on some simple folder, file and tv/chunks naming conventions, the plugin will create these elements for you in the MODx manager:

-   Templates
-   Chunks
-   TVs
-   Context settings


Installation
-------------

1. Download the latest transport package under the packages directory.
2. Copy to your core/packages/ directory.
3. Install in package manager.


Folder Structure
----------------

FEM will recursively parse all contents under web_assets (in your modx root) and create the respective elements (chunks/templates/snippets). The folder names for chunks/templates/snippets can be defined in the plugin\'s properties.

- web_assets/
    - chunks/
        - category/ (optional)
        - subcat/
            - chunk_name.html
    - templates/
        - template_name.html
    - snippets/
        - snippet_name.php

With the setup above, the chunk in file `chunk_name.html` will be created with the name `fem.category.subcat.chunk_name`. You can use this in your template or other chunks now with the usual MODx tag syntax:

`[[$fem.category.subcat.chunk_name]]`

Note that all elements (templates/chunks/snippets/tvs/settings) will have a prefix (`fem.`) in their names. This prefix can be changed in the plugin\'s properties.



TVs
----

To have FEM automagically create a TV and assign it to your template you used it in, use the following naming convention:

`[[*prefix.optional-category.type_name]]`

So for example:

`[[*fem.common.image_banner]]`

Will create a IMAGE TV named `fem.common.image_banner`, captioned as \'banner\' in the category \'common\'. The type must be exactly named as one of the available types in your MODx installation (text, date, image, etc). This TV will now be accessible in the templates you used it in.


Settings
--------

Follow the same naming convention when naming your settings will have them automatically created in your \'web\' context settings.',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'f55d0e6704b3a15beb35253ccad0caba',
      'native_key' => 'fem',
      'filename' => 'modNamespace/1d72575b024349a8fca3051fa7e985b9.vehicle',
      'namespace' => 'fem',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '7cbfa131aa0f1aff3c1e5ac90cdee73e',
      'native_key' => 11,
      'filename' => 'modPlugin/e40da7d7546d84d6be8a4da4608d796c.vehicle',
      'namespace' => 'fem',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '1238ea753542a86e4172d15c9714ef33',
      'native_key' => 1,
      'filename' => 'modCategory/510afbcae93825f261042bf5e75eb37a.vehicle',
      'namespace' => 'fem',
    ),
  ),
);