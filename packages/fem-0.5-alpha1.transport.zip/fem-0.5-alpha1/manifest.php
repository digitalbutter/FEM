<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => '48372644052ff93fa9c22ff6b37d8ab7',
      'native_key' => 'fem',
      'filename' => 'modNamespace/33fac2571c42260c9d03aa7efdb83538.vehicle',
      'namespace' => 'fem',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modPlugin',
      'guid' => '2d2597c1e628f15bb59a43d7e030467c',
      'native_key' => 11,
      'filename' => 'modPlugin/63de5987786f1b3f995206804a12f1d6.vehicle',
      'namespace' => 'fem',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => 'ef4b4e522b02da62ef150efb33d8281e',
      'native_key' => 1,
      'filename' => 'modCategory/3a8fac1e7ac49ac927041e753eb50982.vehicle',
      'namespace' => 'fem',
    ),
  ),
);